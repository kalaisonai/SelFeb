package pages;

import base.BaseUtils;

public class LoginPage extends BaseUtils{

	public LoginPage() {
		
	}
	
	public LoginPage enterUsername(String data) {
		driver.findElementById("username").sendKeys(data);
		return this;
	}
	
	public LoginPage enterPassword(String data) {
		driver.findElementById("password").sendKeys(data);
		return this; 
	}
	
	public HomePage clickLogin() {
		driver.findElementByClassName("decorativeSubmit").click();
		return new HomePage();
		/*HomePage hp = new HomePage();
		return hp;*/  
	}
}









