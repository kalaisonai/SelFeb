package pages;

import base.BaseUtils;

public class HomePage extends BaseUtils{

	public HomePage() {

	}
	
	public LoginPage clickLogout() {
		driver.findElementByClassName("decorativeSubmit").click();
		return new LoginPage(); 
	}
	
	
	
}









