package testCases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseUtils;
import pages.LoginPage;

public class TC001_LoginAndLogout extends BaseUtils {

	@BeforeTest
	public void setData() {
		excelFileName = "TC001";
	}
	@Test(dataProvider="fetchData") 
	public void loginLogout(String uname, String pwd) {
		
		new LoginPage()
		.enterUsername(uname)
		.enterPassword(pwd) 
		.clickLogin() 
		.clickLogout();
		
		
		
		/*LoginPage lp = new LoginPage();
		lp.enterUsername();
		lp.enterPassword();
		lp.clickLogin();*/
		
	}
}









