package week3.day1;

public class SBIChennai extends SBIHeadOffice{

	public  SBIChennai() {
		System.out.println("SBIChennai");
	}  
	@Override
	public void numberOfTran() {
		
	}

	@Override
	public void minBalance() {
		System.out.println("min balance 5000");
		
	}
	
	
	
	
	
	
	
	

	/*@Override
	public void manAadhar() {
		
		
	}

	@Override
	public void numberOfTran() {
		System.out.println("number of transaction 3");
		
	}*/

}
