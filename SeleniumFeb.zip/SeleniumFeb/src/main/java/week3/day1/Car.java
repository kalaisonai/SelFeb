package week3.day1;

public class Car extends Vechicle
{
	public void soundSystem()
	{
		System.out.println("Basic Sound System");
	}
}
