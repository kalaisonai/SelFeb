package week3.day1;

public class Nano extends Car
{

}
