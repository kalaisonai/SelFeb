package week3.day1;

public abstract class LearnAbstract {

	int i =5;
	public abstract void test();
	
	private void test1() {
		
	}
}
