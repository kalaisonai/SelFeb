package week3.day1;

public class Vechicle {
	
	private void speedometer()
	{
		System.out.println("Analog Speedometer");
	}
	
	public void brake()
	{
		System.out.println("Drum Brake");
	}
	
	
	
	
	
	
	
	

}
