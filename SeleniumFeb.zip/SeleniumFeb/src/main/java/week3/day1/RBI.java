package week3.day1;

public interface RBI {

	int transaction =10;
	public void manAadhar() ;
	
	public void numberOfTran();
}
