package week3.day1;

public class Transport {

	static final int n1 =10;
	
	public static void main(String[] args) {
		Transport t = new Transport();
		
		//t.n1;
		
		
		Car obj = new Car();
		//obj.speedometer();
		
		Nano objNano = new Nano();
		objNano.brake();
		objNano.soundSystem();
		
		Audi objAudi = new Audi();
		objAudi.brake();
		objAudi.soundSystem();
		
		
		
		
		
		
		
		
		
		

	}

	
	
}
