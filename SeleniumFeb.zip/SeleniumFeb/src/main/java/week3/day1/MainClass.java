package week3.day1;

public class MainClass {

	public static void main(String[] args) {
		
		SBIChennai sbi = new SBIChennai();
		sbi.manAadhar();
		sbi.minBalance();  
		
		//LearnAbstract la = new LearnAbstract();
		
		
		ICICIChennai icici = new ICICIChennai();
		//icici.numberOfTran();
		//icici.num = 5;
		System.out.println();

	}

}
