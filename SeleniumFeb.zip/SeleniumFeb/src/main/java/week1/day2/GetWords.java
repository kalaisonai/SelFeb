package week1.day2;

public class GetWords {
	public static void main(String[] args) {
		String name = "koushik chatterjee";
		String replace = name.replace('k', 'K');
		System.out.println(replace);
		/*String[] split = name.split(" ");
		for (int i = 0; i < split.length; i++) {
			System.out.println(split[i]);
		}*/
		
	}
}




