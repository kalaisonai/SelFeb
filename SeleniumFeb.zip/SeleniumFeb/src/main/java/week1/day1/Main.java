package week1.day1;

public class Main {

	public static void main(String[] args) {
		
		int[] num = {1,5,7,9,7};
		
		for(int eachNum : num) {
			System.out.println(eachNum); 
		}
		
		
		
		
		
		
		
		/*for(int a=1; a<=5; a++) {
			System.out.println(a); 
		}*/
		
		
		
		
		
		
		
		
		
		
		
		/*int num1 = 16;
		int num2 = 20;
		int num3 = 15;
		if(num1>num2) {
			System.out.println("greatest number "+num1);
		} else {  
			System.out.println("greatest number "+num2);
		}*/
		
		
		
		
		
		
		
		
		
		/*System.out.println(!(num1<num2));
		//System.out.println((num1<num2) || (num1<num3));  
*/		
		
		
		
		
		
		
		
		
		
		
		/*num1++;//num1 = num1+1;
		System.out.println(++num1); 
		System.out.println(num1--);
		System.out.println(num1); */
		
		
		
		
		
		
		/*//int sum = num1+ num2;
		System.out.println(num1+num2);
		System.out.println(num2%num1);*/
		
		
		
		
		
		
		
		
		
		
		
		/*byte num1 = 127;
		long num = 9234567890L;
		float num2 = 45.8F;
		System.out.println(num);
		System.out.println(num2);*/
	
	
	
	
	
	}
}
