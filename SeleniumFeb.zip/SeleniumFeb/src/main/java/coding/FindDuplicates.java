package coding;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.testng.annotations.Test;

public class FindDuplicates {
	
	int[] data = { 1, 3, 3, 7, 8, 8, 9 };

	@Test(enabled = false)
	public void findDups1() {
		for (int i = 0; i < data.length; i++) {
			for (int j = i + 1; j < data.length; j++) {
				if (data[i] == data[j]) {
					System.out.println(data[i]);
					break;
				}
			}
		}

	}
	
	@Test(enabled = false)
	public void findDups2() {
		Arrays.sort(data);
		for (int i = 0; i < data.length-1; i++) {
			if (data[i] == data[i+1]) {
				System.out.println(data[i]);
			}
		}		
	}
	
	@Test
	public void findDups3() {
		Set<Integer> dups = new HashSet<Integer>();
		for (int i = 0; i < data.length; i++) {
			if(dups.add(data[i])== false) {
				System.out.println(data[i]);
			}
		}	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
